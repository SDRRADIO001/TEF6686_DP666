1. Based on the PE5PVB TEF6686_ESP32 v2.11.25 Release Candidate.
2. Use ohmytime's TFT_eSPI-2.5.0 to compile. 
If you need to compile the DP-666 firmware, please make the following changes:
```
#define TFT_INVERSION_ON

#define TFT_MISO 19
#define TFT_MOSI 23
#define TFT_SCLK 18
#define TFT_CS    5  // Chip select control pin
#define TFT_DC   17  // Data Command control pin
#define TFT_RST  16  // Reset pin (could connect to RST pin)
#define TOUCH_CS 32  // Chip select pin (T_CS) of touch screen
```
3. It is recommended to set the SPI default communication rate to 27MHz to obtain the best reception effect.