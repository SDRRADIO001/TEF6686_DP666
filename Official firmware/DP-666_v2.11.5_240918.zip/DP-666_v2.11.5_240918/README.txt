1. Based on the PE5PVB TEF6686_ESP32 2024.09.17 commit 2.11.5
2. Use ohmytime's TFT_eSPI-2.5.0 to compile. 
If you need to compile the DP-666 firmware, please make the following changes:
```
#define TFT_INVERSION_ON

#define TFT_MISO 19
#define TFT_MOSI 23
#define TFT_SCLK 18
#define TFT_CS    5  // Chip select control pin
#define TFT_DC   17  // Data Command control pin
#define TFT_RST  16  // Reset pin (could connect to RST pin)
```
3. It is recommended to set the SPI default communication rate to 27MHz to obtain the best reception effect.